#!/usr/bin/env python3
"""Mutation testing of the mathFunc change (developer-side, not part of make test).

Usage: mutate_v5.py TREE [ID ...]
TREE is a copy of the tree with the change, already built in TREE/unix. Every
mutant is a single text substitution in the new code. For each one the file is
changed, the test shell is rebuilt, tests/mathfuncop.test is run, and the file
is put back. A mutant is CAUGHT if the build fails or any test fails or errors.
Finally the good code is rebuilt and the test file is run once more.
"""
import subprocess, sys, re, os

M = [
 ("M01","ignore_deleted","generic/tclExecute.c",
  "(DELETED | CANCELED | TCL_CANCEL_UNWIND\n\t\t\t| INTERP_DEBUG_FRAME)","(CANCELED | TCL_CANCEL_UNWIND\n\t\t\t| INTERP_DEBUG_FRAME)"),
 ("M02","ignore_canceled","generic/tclExecute.c",
  "(DELETED | CANCELED | TCL_CANCEL_UNWIND","(DELETED | TCL_CANCEL_UNWIND"),
 ("M03","ignore_cancel_unwind","generic/tclExecute.c",
  "(DELETED | CANCELED | TCL_CANCEL_UNWIND","(DELETED | CANCELED"),
 ("M04","ignore_debug_frame","generic/tclExecute.c",
  "TCL_CANCEL_UNWIND\n\t\t\t| INTERP_DEBUG_FRAME))\n\t\t|| (codePtr->compileEpoch","TCL_CANCEL_UNWIND))\n\t\t|| (codePtr->compileEpoch"),
 ("M05","ignore_compile_epoch","generic/tclExecute.c",
  "|| (codePtr->compileEpoch != iPtr->compileEpoch)\n\t\t|| (codePtr->nsEpoch != iPtr->varFramePtr->nsPtr->resolverEpoch)\n\t\t|| (iPtr->numLevels","|| (codePtr->nsEpoch != iPtr->varFramePtr->nsPtr->resolverEpoch)\n\t\t|| (iPtr->numLevels"),
 ("M06","ignore_ns_epoch","generic/tclExecute.c",
  "\t\t|| (codePtr->nsEpoch != iPtr->varFramePtr->nsPtr->resolverEpoch)\n\t\t|| (iPtr->numLevels","\t\t|| (iPtr->numLevels"),
 ("M07","ignore_num_levels","generic/tclExecute.c",
  "\t\t|| (iPtr->numLevels >= iPtr->maxNestingDepth)\n",""),
 ("M08","ignore_lookup_ns","generic/tclExecute.c",
  "\t\t|| iPtr->lookupNsPtr\n",""),
 ("M09","ignore_limit_active","generic/tclExecute.c",
  "\t\t|| iPtr->limit.active) {","\t\t) {"),
 ("M10","no_cmdcount","generic/tclExecute.c",
  "\tiPtr->cmdCount++;\n\tresult = TclMathFuncCall","\tresult = TclMathFuncCall"),
 ("M11","no_interrupt_reset","generic/tclExecute.c",
  "\tinterruptCounter = 1;\n\tgoto resumeFromInvocation;","\tgoto resumeFromInvocation;"),
 ("M12","no_frame_pc","generic/tclExecute.c",
  "\tbcFramePtr->data.tebc.pc = (char *) pc;\n\tiPtr->cmdFramePtr = bcFramePtr;\n\tDECACHE_STACK_INFO();\n\n\t/*\n\t * Count","\tiPtr->cmdFramePtr = bcFramePtr;\n\tDECACHE_STACK_INFO();\n\n\t/*\n\t * Count"),
 ("M13","no_decache","generic/tclExecute.c",
  "\tDECACHE_STACK_INFO();\n\n\t/*\n\t * Count","\n\t/*\n\t * Count"),
 ("M14","ignore_inline_flag","generic/tclBasic.c",
  "if (iPtr->flags & DONT_COMPILE_CMDS_INLINE) {\n\treturn -1;","if (0) {\n\treturn -1;"),
 ("M15","ignore_exec_traces","generic/tclBasic.c",
  "\t    || (cmdPtr->flags & CMD_HAS_EXEC_TRACES)\n\t    || (cmdPtr->nsPtr->flags & NS_SUPPRESS_COMPILATION)) {\n\treturn -1;","\t    || (cmdPtr->nsPtr->flags & NS_SUPPRESS_COMPILATION)) {\n\treturn -1;"),
 ("M16","ignore_suppress_compilation","generic/tclBasic.c",
  "\t    || (cmdPtr->flags & CMD_HAS_EXEC_TRACES)\n\t    || (cmdPtr->nsPtr->flags & NS_SUPPRESS_COMPILATION)) {\n\treturn -1;","\t    || (cmdPtr->flags & CMD_HAS_EXEC_TRACES)) {\n\treturn -1;"),
 ("M17","no_marker_check","generic/tclBasic.c",
  "if (cmdPtr == NULL || cmdPtr->compileProc != TclCompileMathFuncCmd\n","if (cmdPtr == NULL\n"),
 ("M18","match_proc_only","generic/tclBasic.c",
  "\t\t&& (void *) defPtr->fn == cmdPtr->objClientData2) {\n\t    return (int)","\t\t) {\n\t    return (int)"),
 ("M19","no_marker_at_creation","generic/tclBasic.c",
  "\tcmdPtr->compileProc = TclCompileMathFuncCmd;\n\tTcl_Export(interp, nsPtr, builtinFuncPtr->name, 0);","\tTcl_Export(interp, nsPtr, builtinFuncPtr->name, 0);"),
 ("M20","setinfo_no_clear","generic/tclBasic.c",
  "\tcmdPtr->compileProc = NULL;\n\t((Interp *) cmdPtr->nsPtr->interp)->compileEpoch++;","\t((Interp *) cmdPtr->nsPtr->interp)->compileEpoch++;"),
 ("M21","setinfo_no_bump","generic/tclBasic.c",
  "\tcmdPtr->compileProc = NULL;\n\t((Interp *) cmdPtr->nsPtr->interp)->compileEpoch++;","\tcmdPtr->compileProc = NULL;"),
 ("M22","width_limit_257","generic/tclCompExpr.c",
  "numWords < 256","numWords < 257"),
 ("M23","bypass_emit_invoke","generic/tclCompExpr.c",
  "INVOKE41(\tMATH_FUNC, nodePtr->right, numWords);","OP11(\tMATH_FUNC, nodePtr->right, numWords);"),
 ("M24","errorstack_name_not_mapped","generic/tclDisassemble.c",
  "(*pc == INST_MATH_FUNC) ? INST_INVOKE_STK : *pc","*pc"),
 ("M25","errorstack_wrong_objc","generic/tclDisassemble.c",
  "case INST_MATH_FUNC:\n\tobjc = TclGetUInt1AtPtr(pc + 2);","case INST_MATH_FUNC:\n\tobjc = 1;"),
 ("M26","emit_invoke_wordcount","generic/tclCompile.c",
  "wordCount = cleanup = arg2;","wordCount = cleanup = arg2 - 1;"),
 ("M27","stack_effect_operand","generic/tclCompile.h",
  "TclUpdateStackReqs(op, j, envPtr);\n}\n\nstatic inline void\nTclEmitInstInt41(","TclUpdateStackReqs(op, i, envPtr);\n}\n\nstatic inline void\nTclEmitInstInt41("),
 ("M28","cleanup_count","generic/tclExecute.c",
  "\tobjv = &OBJ_AT_DEPTH(objc - 1);\n\tcleanup = objc;\n\tbcFramePtr->data.tebc.pc","\tobjv = &OBJ_AT_DEPTH(objc - 1);\n\tcleanup = objc - 1;\n\tbcFramePtr->data.tebc.pc"),
]

def run(cmd, cwd):
    return subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True)

def tally(out):
    m = re.search(r"Total\s+(\d+)\s+Passed\s+(\d+)\s+Skipped\s+(\d+)\s+Failed\s+(\d+)", out)
    return tuple(int(x) for x in m.groups()) if m else None

def test(tree):
    unix = os.path.join(tree, "unix")
    b = run("make -j2 tcltest", unix)
    if b.returncode != 0:
        return "BUILD-FAIL", None, []
    env = "LD_LIBRARY_PATH=%s TCL_LIBRARY=%s" % (unix, os.path.join(tree, "library"))
    t = run(env + " timeout 600 ./tcltest ../tests/mathfuncop.test", unix)
    out = t.stdout + t.stderr
    tl = tally(out)
    failed = sorted(set(re.findall(r"^==== (\S+) .*FAILED", out, re.M)))
    if tl is None:
        return "CRASH", None, failed
    return ("CAUGHT" if (tl[3] > 0 or t.returncode != 0) else "MISSED"), tl, failed

def main():
    tree = os.path.abspath(sys.argv[1])
    ids = sys.argv[2:]
    for mid, name, f, old, new in M:
        if ids and mid not in ids:
            continue
        path = os.path.join(tree, f)
        orig = open(path).read()
        if orig.count(old) != 1:
            print(mid, name, "SKIP: pattern found %d times" % orig.count(old), flush=True)
            continue
        try:
            open(path, "w").write(orig.replace(old, new))
            status, tl, failed = test(tree)
        finally:
            open(path, "w").write(orig)
        print(mid, name, status, ("%d failed" % tl[3]) if tl else "", " ".join(failed[:4]), flush=True)
    status, tl, failed = test(tree)
    print("restored good code:", status, tl, flush=True)

main()
