# Differential test of the mathFunc instruction against stock Tcl.
#
# Runs the same sweeps and scenarios as group 3 of tests/mathfuncop.test, but
# with no switch to turn the instruction off: the whole outcome of every
# script (return code, result, and for errors the error code, error info,
# error line and error stack) is printed. Run it with the "tcltest" shell of
# a stock build and of the build with the change (the scenarios use the test
# commands testasync and testcmdtrace); the two outputs must be identical.
#
#   ./tcltest mf_diff.tcl > out_stock      (in the stock build directory)
#   ./tcltest mf_diff.tcl > out_new        (in the build with the change)
#   cmp out_stock out_new
#
# Generated from the test file; the helpers below are the only differences.

proc outcome {script} {
    set code [catch {uplevel 1 $script} m opts]
    set out "$code [list $m]"
    if {$code} {
	foreach k {-errorcode -errorinfo -errorline -errorstack} {
	    if {[dict exists $opts $k]} {
		append out " $k=[list [dict get $opts $k]]"
	    }
	}
    }
    return $out
}
proc mkchild {name mode} {
    interp create $name
    $name eval {tcl::mathfunc::srand 12345}
    return $name
}
# Functions and argument lists that succeed / fail, for the scenarios.
set okargs {
	sin {0.5} pow {2 10} atan2 {1 2} ldexp {1.5 3} abs {-3} int {2.7}
	double {3} bool {yes} ceil {1.2} floor {1.7} round {2.5} isqrt {99}
	sqrt {16} isnan {NaN} isunordered {1 NaN} max {3 9 4} min {3 9 4}
	fma {2 3 4} lgamma {5} wide {5} entier {1e20} rand {} srand {7}
	copysign {3 -1} hypot {3 4} log {2.718281828} signbit {-0.0}
	trunc {2.9} cbrt {27} isfinite {1} issubnormal {1e-320}
}
set badargs {
	sin {zz} pow {2} atan2 {1} ldexp {1 zz} abs {zz} int {zz} double {zz}
	bool {zz} ceil {zz} floor {zz} round {zz} isqrt {-4} sqrt {-1}
	isnan {zz} isunordered {1} max {zz 1} min {1 zz} fma {2 3}
	lgamma {zz} wide {zz} entier {zz} rand {1} srand {zz} copysign {1}
	hypot {1} log {-1} signbit {zz} trunc {zz} cbrt {zz} isfinite {zz}
	issubnormal {zz}
}

# Argument values for the sweep over every function.
set v1 {
	0 -0 1 -1 2 7 -7 0.5 -2.5 1e300 1e-300
	9223372036854775807 -9223372036854775808 9223372036854775808
	123456789012345678901234567890 Inf -Inf NaN 0x10 010 " 5" "" a 1.0 -0.0
	3.14159 65 {1 2} 1e400 true
}
set v2 {0 1 -1 2.5 1e300 9223372036854775807 NaN a}
set v3 {0 -1 2.5 a}

# Every math function, many argument lists, called inside expr (the
# instruction) and, for reference, directly as a command (invokeStk).
proc sweep {f} {
    global v1 v2 v3
	set v1
	set v2
	set v3
	set isRand [expr {$f in {rand srand}}]
	proc d0 {} "tcl::mathfunc::$f"
	proc d1 {a} "tcl::mathfunc::$f \$a"
	proc d2 {a b} "tcl::mathfunc::$f \$a \$b"
	proc d3 {a b c} "tcl::mathfunc::$f \$a \$b \$c"
	proc e0 {} "expr {${f}()}"
	proc e1 {a} "expr {${f}(\$a)}"
	proc e2 {a b} "expr {${f}(\$a,\$b)}"
	proc e3 {a b c} "expr {${f}(\$a,\$b,\$c)}"
	proc n1 {a} "expr {1 + ${f}(\$a) * 1}"
	set out {}
	set argsets {{}}
	foreach a $v1 {lappend argsets [list $a]}
	foreach a $v2 {foreach b $v2 {lappend argsets [list $a $b]}}
	foreach a $v3 {foreach b $v3 {foreach c $v3 {
	    lappend argsets [list $a $b $c]
	}}}
	foreach args $argsets {
	    set n [llength $args]
	    if {$isRand} {tcl::mathfunc::srand 12345}
	    set r1 [outcome {d$n {*}$args}]
	    if {$isRand} {tcl::mathfunc::srand 12345}
	    set r2 [outcome {e$n {*}$args}]
	    if {$n == 1} {
		if {$isRand} {tcl::mathfunc::srand 12345}
		append r2 " | [outcome {n1 {*}$args}]"
	    }
	    append out "$f [list $args] | $r1 | $r2\n"
	}
	rename d0 {}; rename d1 {}; rename d2 {}; rename d3 {}
	rename e0 {}; rename e1 {}; rename e2 {}; rename e3 {}
	rename n1 {}
	return $out
}

# Guards and interpreter interactions, per function.
proc scenarios {f a b mode} {
	set out {}
	set isRand [expr {$f in {rand srand}}]
	set I [mkchild mf_I $mode]
	$I eval [list set f $f]
	$I eval [list set a $a]
	$I eval [list set b $b]
	$I eval {
	    proc direct {} [list tcl::mathfunc::$f {*}$a]
	    proc viaexpr {} "expr {${f}([join $a ,])}"
	    proc bad {} "expr {${f}([join $b ,])}"
	    proc tr {args} {lappend ::log $args}
	    set ::log {}
	}
	proc line {label script} {
	    upvar 1 out out I I
	    append out "$label: [outcome {$I eval $script}]\n"
	}
	set seed {if {$f in {rand srand}} {tcl::mathfunc::srand 99}}
	line plain "$seed; list \[direct\] \[viaexpr\]"
	line bad {bad}
	line badcatch {catch {bad} m o; list $m [dict get $o -errorcode] [dict get $o -errorline]}
	line trace_on "set ::log {}
	    trace add execution tcl::mathfunc::$f {enter leave} tr
	    $seed
	    set r \[list \[direct\] \[viaexpr\]\]
	    trace remove execution tcl::mathfunc::$f {enter leave} tr
	    list \$r \$::log"
	line trace_off "$seed; list \[viaexpr\] \$::log"
	line trace_err "proc trerr args {error tracefail}
	    trace add execution tcl::mathfunc::$f enter trerr
	    set c \[catch viaexpr m\]
	    trace remove execution tcl::mathfunc::$f enter trerr
	    list \$c \$m"
	line cmdcount {set x [info cmdcount]; viaexpr; viaexpr; direct; expr {[info cmdcount] - $x}}
	line rename_away "rename tcl::mathfunc::$f ::saved_fn
	    set c \[catch viaexpr m\]
	    rename ::saved_fn tcl::mathfunc::$f
	    list \$c \$m \[viaexpr\]"
	line redefine "rename tcl::mathfunc::$f ::saved_fn
	    proc tcl::mathfunc::$f args {return REDEF}
	    set r \[list \[direct\] \[catch viaexpr m\] \$m\]
	    rename tcl::mathfunc::$f {}
	    rename ::saved_fn tcl::mathfunc::$f
	    list \$r \[viaexpr\]"
	line delete "rename tcl::mathfunc::$f ::saved_fn
	    rename ::saved_fn {}
	    set c \[catch viaexpr m\]
	    list \$c \$m"
	line alias "interp alias {} al_$f {} tcl::mathfunc::$f
	    proc viaal {} \[list al_$f {*}\$::a\]
	    $seed; viaal"
	line try_loop {set r {}; for {set i 0} {$i < 3} {incr i} {try {bad} on error {m} {lappend r $m}}; set r}
	line coro {coroutine co1 apply {{} {yield [viaexpr]; viaexpr; return done}}; list [co1] [co1]}
	line tailcall {proc tc {} {tailcall viaexpr}; tc}
	line uplevel {proc up {} {uplevel 1 viaexpr}; up}
	interp delete $I

	# Command limit: must stop at the same iteration in both passes.
	foreach lim {7 30} {
	    set L [mkchild mf_L $mode]
	    $L eval [list set f $f]
	    $L eval [list set a $a]
	    $L eval {proc lp {} "set i 0; while 1 {expr {${::f}([join $::a ,])}; incr i; set ::i \$i}"}
	    $L limit command -value [expr {[$L eval {info cmdcount}] + $lim}]
	    set o [outcome {$L eval lp}]
	    $L limit command -value {}
	    append out "limit $lim: $o i=[$L eval {set ::i}]\n"
	    interp delete $L
	}
	set L [mkchild mf_L $mode]
	$L eval [list set f $f]
	$L eval [list set a $a]
	$L eval {proc lp {} "set i 0; while 1 {expr {1}; expr {${::f}([join $::a ,])}; incr i; set ::i \$i}"}
	$L limit command -value [expr {[$L eval {info cmdcount}] + 60}] -granularity 5
	set o [outcome {$L eval lp}]
	$L limit command -value {}
	append out "limit granularity: $o i=[$L eval {set ::i}]\n"
	interp delete $L

	# A time limit that has already expired.
	set L [mkchild mf_L $mode]
	$L eval [list set f $f]
	$L eval [list set a $a]
	$L eval {proc lp {} "for {set i 0} {\$i < 3} {incr i} {expr {${::f}([join $::a ,])}}; return done"}
	$L limit time -seconds [expr {[clock seconds] - 10}]
	append out "expired time limit: [outcome {$L eval lp}]\n"
	interp delete $L

	# Cancel from inside the loop.
	set C [mkchild mf_C $mode]
	$C eval [list set f $f]
	$C eval [list set a $a]
	$C eval {proc cm {} "
	    set r 0
	    for {set i 0} {\$i < 8} {incr i} {
		if {\$i == 3} {interp cancel}
		expr {${::f}([join $::a ,])}
		set r \$i
	    }
	    return \$r
	"}
	append out "cancel: [outcome {$C eval cm}]\n"
	append out "after cancel: [outcome {$C eval {set x 1}}]\n"
	interp delete $C

	# Recursion limit at several depths.
	set R [mkchild mf_R $mode]
	$R eval [list set f $f]
	$R eval [list set a $a]
	$R eval {proc deep {n} "
	    if {\$n == 0} {return \[expr {${::f}([join $::a ,])}\]}
	    deep \[expr {\$n-1}\]
	"}
	foreach d {10 37 38 39 40 41 60} {
	    $R eval {interp recursionlimit {} 40; tcl::mathfunc::srand 5}
	    append out "deep $d: [outcome {$R eval [list deep $d]}]\n"
	}
	interp delete $R
	rename line {}
	return $out
}

# Other callers and environments, using abs/int/double.
proc misc {mode} {
	set out {}
	proc line {label script} {
	    upvar 1 out out
	    append out "$label: [outcome {uplevel 1 $script}]\n"
	}
	line eval_global   {eval {expr {abs(-2)}}}
	line uplevel_zero  {uplevel #0 {expr {int(7.7)}}}
	line string_eval   {eval "expr {double(5)}"}
	line apply         {apply {{x} {expr {abs($x)}}} -6}
	line expr_args     {expr abs(-6) + int(2.5)}
	line expr_words    {set x -6; expr abs($x) * 2}
	line dyn_name      {set f abs; expr {$f(-3)}}
	line dyn_name_mf   {set f abs; expr "tcl::mathfunc::$f(-3)"}
	line assemble      {tcl::unsupported::assemble {push tcl::mathfunc::abs; push -3; invokeStk 2}}
	line assemble_bad  {tcl::unsupported::assemble {push tcl::mathfunc::abs; push zz; invokeStk 2}}
	line results {
	    set a [expr {abs(-5)}]
	    set b [expr {abs(-6)}]
	    set c [expr {int($a)}]
	    list $a $b $c [string length $a] [expr {$a + $b}]
	}
	line errcode {
	    catch {expr {abs("q")}} m o
	    set e1 [dict get $o -errorcode]
	    catch {expr {abs(5)}} m2 o2
	    list $e1 $m2 [dict exists $o2 -errorcode] $::errorCode
	}
	line errorInfo_global {catch {expr {abs("q")}}; set ::errorInfo}
	line result_reset {
	    set x [expr {abs(-2)}]
	    interp result {}
	    set y [expr {abs(-3)}]
	    list $x $y
	}
	line ensemble_after {
	    catch {string foo} m
	    expr {abs(-1)}
	    catch {string foo} m2
	    list $m $m2
	}
	line const_fold    {expr {abs(-5) + int(2.5) * 3}}
	line nested_mixed  {expr {max(abs(-2), [expr {int(3.5)}], min(9, 4)) + sqrt(16)}}
	line cond_expr     {expr {abs(-1) > 0 ? int(2.5) : double(3)}}
	line logic         {expr {abs(-1) > 0 && int(2.5) == 2 || sqrt(-1) > 0}}
	line big_args      {expr {max([join [lrepeat 40 7] ,])}}
	# Namespaces: relative names, shadowing, import.
	namespace eval ::mf_q {
	    proc t1 {} {expr {abs(-5)}}
	    proc t2 {} {expr {tcl::mathfunc::abs(-5)}}
	}
	line ns_calls {list [::mf_q::t1] [catch {::mf_q::t2} m] $m}
	namespace eval ::tcl::mathfunc {
	    proc mf_t3 {} {expr {abs(-5)}}
	    proc mf_t4 {} {expr {int(5.9)}}
	}
	line ns_inside_mathfunc {list [::tcl::mathfunc::mf_t3] [::tcl::mathfunc::mf_t4]}
	rename ::tcl::mathfunc::mf_t3 {}
	rename ::tcl::mathfunc::mf_t4 {}
	namespace eval ::mf_q {
	    namespace eval tcl::mathfunc {proc abs {x} {return "q::abs($x)"}}
	}
	line ns_shadow {list [catch {::mf_q::t1} m] $m}
	namespace delete ::mf_q
	namespace eval ::mf_z {namespace import ::tcl::mathfunc::int; proc t {} {expr {int(8.8)}}}
	line ns_import {::mf_z::t}
	namespace delete ::mf_z
	interp alias {} mf_myint {} tcl::mathfunc::int
	proc mf_viaalias {} {expr {int(3.9)}}
	line alias_bc {mf_viaalias}
	rename ::tcl::mathfunc::int ::mf_hid_int
	line alias_after_rename {catch {mf_viaalias} m; set m}
	rename ::mf_hid_int ::tcl::mathfunc::int
	line alias_back {mf_viaalias}
	rename mf_myint {}
	rename mf_viaalias {}
	# Safe interpreter and hidden command.
	set S [interp create -safe mf_S]
	if {$mode} {testmathfuncop off mf_S}
	line safe_expr {mf_S eval {expr {abs(-3) + int(2.5) + double(1)}}}
	mf_S eval {proc w {x} {expr {abs($x)}}}
	mf_S eval {rename tcl::mathfunc::abs ::gabs}
	line safe_moved {mf_S eval {catch {w -3} m; set m}}
	mf_S hide gabs
	line safe_hidden {mf_S eval {catch {w -3} m; set m}}
	line safe_hidden_invoke {mf_S invokehidden gabs -3}
	mf_S expose gabs
	mf_S eval {rename ::gabs tcl::mathfunc::abs}
	line safe_exposed {mf_S eval {w -3}}
	interp delete mf_S
	# Coroutine.
	proc mf_gen {} {
	    yield [expr {abs(-1)}]
	    yield [expr {int(2.5)}]
	    yield [expr {double(3)}]
	    return [expr {abs(-4)}]
	}
	coroutine mf_g1 mf_gen
	line coro {list [mf_g1] [mf_g1] [mf_g1] [catch {mf_g1} m] $m}
	rename mf_gen {}
	# The same procedure called while a function is changed, and before.
	proc mf_p {x} {expr {abs($x) + 1}}
	line same_proc_1 {mf_p -3}
	rename ::tcl::mathfunc::abs ::mf_saved
	proc ::tcl::mathfunc::abs {x} {return 100}
	line same_proc_2 {mf_p -3}
	rename ::tcl::mathfunc::abs {}
	rename ::mf_saved ::tcl::mathfunc::abs
	line same_proc_3 {mf_p -3}
	rename mf_p {}
	# A body that changes the function between two of its own calls.
	proc mf_p2 {} {
	    set a [expr {abs(-3)}]
	    rename ::tcl::mathfunc::abs ::mf_saved
	    proc ::tcl::mathfunc::abs {x} {return CHANGED}
	    set b [expr {abs(-3)}]
	    rename ::tcl::mathfunc::abs {}
	    rename ::mf_saved ::tcl::mathfunc::abs
	    set c [expr {abs(-3)}]
	    list $a $b $c
	}
	line change_between {mf_p2}
	line change_between_again {mf_p2}
	rename mf_p2 {}
	rename line {}
	return $out
}

# States that make the instruction fall back to invokeStk, observed
# through a side effect (srand changes the generator that rand then
# reads), so a call that wrongly ran, or wrongly skipped, shows up in the
# result.
proc extras {mode} {
	set out {}
	proc line {label script} {
	    upvar 1 out out
	    append out "$label: [outcome {uplevel 1 $script}]\n"
	}
	# A cancel request already pending when the call is made.
	foreach un {{} -unwind} {
	    set I [mkchild mf_X $mode]
	    $I eval {tcl::mathfunc::srand 1}
	    $I eval {proc sr {} {expr {srand(77)}}}
	    line cancel$un {$I eval "interp cancel $un; sr"}
	    line cancel${un}_after {$I eval {expr {rand()}}}
	    interp delete $I
	}
	# Cancel raised inside a proc, then the very next call.
	set I [mkchild mf_X $mode]
	$I eval {
	    proc c1 {} {expr {srand(1)}; interp cancel; expr {srand(77)}; return notreached}
	}
	line cancel_proc {$I eval c1}
	line cancel_proc_after {$I eval {expr {rand()}}}
	interp delete $I
	# A command limit that is already exceeded when the call is reached.
	foreach lim {2 3 4 5} {
	    set I [mkchild mf_X $mode]
	    $I eval {
		proc lp {} {
		    for {set n 0} {$n < 1000} {incr n} {expr {srand(77)}; expr {srand(1)}}
		}
	    }
	    $I limit command -value [expr {[$I eval {info cmdcount}] + $lim}]
	    line limit$lim {$I eval lp}
	    $I limit command -value {}
	    line limit${lim}_after {$I eval {expr {rand()}}}
	    interp delete $I
	}
	# An asynchronous handler that fires while a call is in progress.
	foreach h {{set ::seen 1} {error handlerfail} {return -code break} {interp cancel}} {
	    set id [testasync create $h]
	    set ::seen 0
	    proc ap {} {
		expr {srand(1)}
		testasync mark $::id
		set a [expr {srand(77)}]
		return [list $a [info cmdcount]]
	    }
	    set ::id $id
	    line async-[string range $h 0 6] {
		set c [catch ap m o]
		list $c $m [dict get $o -errorinfo] $::seen [expr {rand()}]
	    }
	    testasync delete $id
	}
	# Command tracing at the C level (Tcl_CreateObjTrace2).
	proc tp {} {list [expr {abs(-5)}] [expr {int(2.5)}]}
	tp
	line cmdtrace {testcmdtrace tracetest tp}
	line cmdtrace_after {tp}
	# Frame debugging, which is one-way for an interpreter.
	set I [mkchild mf_X $mode]
	interp debug $I -frame 1
	$I eval {proc dbg {} {list [expr {abs(-5)}] [info frame]}}
	line debugframe {$I eval dbg}
	line debugframe_err {$I eval {catch {expr {abs("q")}} m o; list $m [dict get $o -errorinfo]}}
	interp delete $I
	# A deleted interpreter.
	set I [mkchild mf_X $mode]
	interp alias $I killme {} interp delete $I
	$I eval {proc dl {} {killme; expr {abs(-5)}}}
	line deleted_child {catch {$I eval dl} m; set m}
	catch {interp delete $I}
	rename line {}
	return $out
}


set funcs [lsort [info commands ::tcl::mathfunc::*]]
foreach c $funcs {
    set f [namespace tail $c]
    puts "=== sweep $f"
    puts -nonewline [sweep $f]
}
foreach {f a} $okargs {
    puts "=== scenarios $f"
    puts -nonewline [scenarios $f $a [dict get $badargs $f] 0]
}
puts "=== misc"
puts -nonewline [misc 0]
puts "=== extras"
puts -nonewline [extras 0]
