#!/bin/sh
# usage: wall_v5.sh STOCK_TREE NEW_TREE [ROUNDS]  -> medians of ns/iteration, interleaved rounds
S=$1; N=$2; R=${3:-7}
T=${TMPDIR:-/tmp}/wall.$$; mkdir -p $T
for r in $(seq $R); do
  for w in stock new; do
    if [ $w = stock ]; then U=$S/unix; else U=$N/unix; fi
    LD_LIBRARY_PATH=$U TCL_LIBRARY=$U/../library $U/tclsh "$(dirname "$0")/wall3.tcl" > $T/$w.$r
  done
done
python3 - $T $R <<'PY'
import sys, statistics
T, R = sys.argv[1], int(sys.argv[2])
d = {'stock': {}, 'new': {}}
for w in d:
    for r in range(1, R + 1):
        for line in open("%s/%s.%d" % (T, w, r)):
            f, v = line.split()
            d[w].setdefault(f, []).append(float(v))
print("%-8s %8s %8s %8s" % ("func", "stock", "new", "change"))
for f in d['stock']:
    a = statistics.median(d['stock'][f]); b = statistics.median(d['new'][f])
    print("%-8s %8.1f %8.1f %+7.1f%%" % (f, a, b, (b - a) * 100 / a) if f != 'empty' else "%-8s %8.1f %8.1f  (loop only)" % (f, a, b))
PY
rm -rf $T
