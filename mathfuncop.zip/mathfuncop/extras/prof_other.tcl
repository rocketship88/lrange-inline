lassign $argv f N
proc id {x} {return $x}
array set B {empty {} proc {id 5} lsearch {lsearch {a b c} c} strlen {string length abc} userfn {expr {id2(3)}}}
proc tcl::mathfunc::id2 {x} {return $x}
proc p {N} "for {set k 0} {\$k < \$N} {incr k} {$B($f)}"
p $N
exit
