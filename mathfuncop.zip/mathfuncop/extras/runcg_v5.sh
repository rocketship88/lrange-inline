#!/bin/sh
# usage: runcg_v5.sh STOCK_TREE|NEW_TREE FUNC N   -> total instructions (callgrind) for N loop iterations
# needs valgrind; prints the "Collected" count. Subtract the "empty" run to get per-call cost.
U=$1/unix
export LD_LIBRARY_PATH=$U TCL_LIBRARY=$U/../library
OUT=${TMPDIR:-/tmp}/cg.$$.out
valgrind --tool=callgrind --callgrind-out-file=$OUT.cg $U/tclsh "$(dirname "$0")/prof6.tcl" $2 $3 2> $OUT.err >/dev/null
grep -h "Collected" $OUT.err | awk '{print $4}'
rm -f $OUT.cg $OUT.err
