mathfuncop: a mathFunc instruction for calls of the built-in math functions in expressions
==========================================================================================

PROTOTYPE. Written and checked by Claude (an AI); not reviewed by anyone else.

Base: Tcl main, commit 3d77be8951 (2026-10-11), the newest at the time of writing.
Not in Fossil. This is the "opcode" alternative to the earlier "fastleaf" change
(a shorter C call path). The two are different answers to the same question and
are NOT meant to be combined; this tree contains no fast-path code.

Layout
  orig/   the 8 source files that changed, as they were at the base commit
  new/    the same 8 files after the change, plus the new tests/mathfuncop.test
  mathfuncop.patch   the same change as a unified diff (git format, includes the new test):
                       git apply mathfuncop.patch      or     patch -p1 < mathfuncop.patch
                     run from the Tcl source root. Checked: applies cleanly to a fresh
                     clone of 3d77be8951 and the result is byte-identical to new/.
  CHECKSUMS.txt      SHA-256 of every file in new/ and then orig/
  RESULTS.txt        tests and measurements
  extras/            scripts and result files (see "Checks" below)

What it does
  In an expression, a call of a built-in math function, e.g. expr {sin($x) + abs($y)},
  used to compile to: push "tcl::mathfunc::sin", push args, invokeStk N, so every
  call went through the generic command-call machinery. Now, when the name resolves
  at compile time to an unmodified built-in math function, the compiler emits
        mathFunc <index> <words>        (3 bytes: opcode, function table index, word count)
  instead of invokeStk. The function name is still pushed, so the stack is exactly
  what invokeStk would have seen. The instruction calls the C implementation directly
  and does what the normal route would do around it (command count, error context).

  If anything is not as the compiler found it when the instruction runs, it executes
  exactly as invokeStk (looks the command up by name and calls it), so the
  result is whatever stock Tcl gives. Stock Tcl's own epoch machinery is reused for this;
  there is no new invalidation mechanism:
    * The 58 built-in math commands carry a marker in Command.compileProc
      (TclCompileMathFuncCmd, which declines to compile, so a direct call
      "tcl::mathfunc::abs $x" is compiled exactly as before). Because compileProc is
      non-NULL, Tcl already bumps compileEpoch when such a command is deleted, renamed,
      hidden, exposed, or gets an execution trace, and bumps the namespace's resolverEpoch
      when a command that shadows it is created. Tcl_SetCommandInfoFromToken
      (the C API that replaces a command's implementation) clears the marker and bumps
      compileEpoch (added).
    * At compile time (TclMathFuncIndex) the instruction is used only if the name
      resolves to a command that still has the marker and whose C function pair is a
      built-in's (so renamed built-ins still work), with no execution traces, no
      interp-wide trace (DONT_COMPILE_CMDS_INLINE) and no NS_SUPPRESS_COMPILATION
      (TclOO object namespaces).
    * At run time the handler falls back to the invokeStk behaviour if the interp
      is deleted/canceled/in debug-frame mode, compileEpoch or the namespace
      resolverEpoch changed since compilation (a function redefined by an earlier part
      of the same command), the recursion limit is reached, a lookup namespace is
      pending, or a command limit is active.
  Error reporting: -errorinfo, -errorcode, -errorline and -errorstack are identical to
  stock (the instruction is reported as "invokeStk" with the same words).

Files changed
  generic/tclCompile.h      INST_MATH_FUNC (appended at the end of the opcode enum, so existing
                            opcode numbers do not change); TclEmitInstInt11 / OP11
  generic/tclCompile.c      instruction table entry; TclEmitInvoke handles MATH_FUNC (so
                            break/continue stack unwinding wrappers apply as for invokeStk)
  generic/tclCompExpr.c     CompileExprTree: emit mathFunc instead of invokeStk when allowed
                            (and fewer than 256 words)
  generic/tclBasic.c        marker on the 58 functions; TclMathFuncIndex, TclMathFuncCall,
                            TclCompileMathFuncCmd; Tcl_SetCommandInfoFromToken clears marker
  generic/tclInt.h          declarations
  generic/tclExecute.c      the instruction handler (and a resume label shared with invokeStk's resume)
  generic/tclDisassemble.c  disassembly of the operands; -errorstack reports invokeStk
  generic/tclTest.c         test command  testmathfuncop ?off|on? ?child?  (switches the marker off
                            so the same script can be run through invokeStk in the same binary)
  tests/mathfuncop.test     131 tests

How to try it
  1. Take a Tcl tree at 3d77be8951; apply mathfuncop.patch from its root.
  2. Build as usual (unix: cd unix; ./configure; make; make tcltest).
  3. Tests:   cd unix; ./tcltest ../tests/mathfuncop.test     (also picked up by make test)
     The tests need the test build because they use testmathfuncop, testcmdinfo etc.
     The behaviour tests (groups 2 and 3) also pass on a stock build; only the
     disassembly checks (group 1) are specific to the change.
  4. Differential scripts. Run with the stock build and with the new build, then cmp the outputs:
        tclsh   extras/ff_all.tcl    every function x 47,734 argument lists, direct and inside expr
        tclsh   extras/ff_scen.tcl   traces, redefinition, limits, cancel, recursion, ...
        tclsh   extras/ff_tests.tcl  namespaces, safe interps, hidden commands, ...
        tcltest extras/mf_diff.tcl   the scenarios of group 3 of the test file, no switches (needs tcltest)
     Note: ff_*.tcl call each function both directly by name (not compiled to the instruction)
     and inside expr (compiled to it); mf_diff.tcl uses expr.
  5. Mutation check:  python3 extras/mutate_v5.py TREE [M01 ...]   (TREE = a scratch copy of the
     built new tree; it edits generic/*.c, rebuilds tcltest, runs mathfuncop.test, restores).
  6. Timing: extras/wall_v5.sh STOCK_TREE NEW_TREE 7   (needs wall3.tcl alongside);
     extras/runcg_v5.sh TREE FUNC N   (callgrind, needs valgrind; prof6.tcl alongside).

Behaviour notes and limits
  * Only function calls inside expressions use the instruction. A direct call written as a
    command, "tcl::mathfunc::abs $x", is compiled as before (the marker makes the compiler
    decline). The instruction has no assembler (tcl::unsupported::assemble) form.
  * Calls with 256 or more words (255+ arguments) use invokeStk (the word count is one byte).
  * Bytecode is not compatible across this change in the usual sense that a new opcode exists;
    the opcode is appended so no existing opcode number moves.
  * Instruction is 3 bytes versus invokeStk's 5; opcode count 211 -> 212 (this base, without the lrange change).
  * Both this change and the lrange change append an opcode to the end of the opcode enum and
    the instruction table, so they will conflict textually in those two spots (trivially);
    I have not built them together.
  * Only built and tested on Linux x86-64 (gcc -O2); also compiled with TCL_COMPILE_DEBUG and with
    REMOVE_DEPRECATED_OPCODES. Not tried on Windows or macOS.
  * In a TCL_COMPILE_DEBUG build with command tracing on, the instruction runs as invokeStk.
  * Some run-time guards (deleted/canceled/cancel-unwind/debug-frame interp flags, lookupNsPtr)
    cannot be reached from a script at the moment the instruction runs; they are there so the
    instruction behaves exactly like the generic route, and the tests cannot tell them apart (see
    the mutation results in RESULTS.txt).

Checks (details and numbers in RESULTS.txt)
  full make test; four differential scripts against a stock build; 28 mutations of the change;
  valgrind memcheck of the differential scripts and the test file; callgrind and wall-clock timing.
