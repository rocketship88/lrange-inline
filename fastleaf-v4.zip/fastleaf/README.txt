fastleaf: a shorter call path from bytecode for the built-in math functions (all 58 flagged)
=====================================================================================

PROTOTYPE. Written and checked by Claude (an AI); not reviewed by anyone else.

Base: Tcl main, commit 78dedf7 (2026-10-05), the same base as the lrange change.
It is independent of the lrange change: both patches apply to the base one after
the other without conflicts (checked by applying only; not built together).

Layout
  orig/   the 4 source files that changed, as they were
  new/    the same 4 files after the change, plus the new tests/fastleaf.test
  fastleaf.patch   the same change as a unified diff:  patch -p1 < fastleaf.patch
                   run from the Tcl source root (it edits generic/*.c, *.h and adds tests/fastleaf.test)
  CHECKSUMS.txt    SHA-256 of every file in orig/ and new/
  RESULTS.txt      tests and measurements
  extras/          mutate.py, runmut.sh, mutation_results_*.txt (see Tests)
                   ff_tests.tcl  behaviour transcript (see below)
                   wall2.tcl     wall-clock benchmark
                   prof5.tcl, runcg.sh   callgrind harness (needs valgrind)

What changed
  generic/tclInt.h      new command flag CMD_FAST_LEAF (0x100); prototype of
                        TclFastLeafInvoke; new interp flag FAST_LEAF_OFF
                        (0x2000) that makes the path decline. Nothing in
                        the core sets it; only the test command does.
  generic/tclTest.c     test-only commands: testfastleaf (see Tests) and
                        testfastleafprobe (a flagged probe command).
  generic/tclBasic.c    when the math functions are registered, the flag is set
                        on every one of the 58 ::tcl::mathfunc functions. New function
                        TclFastLeafInvoke: if the command has no execution
                        traces, is not dead, has no NR implementation, and the
                        interp has no trace, limit exceeded, cancel, rewind,
                        debug-frame or deferred callbacks, it runs the command
                        by a shorter path and does what the normal route does after it
                        (command count, level count, interp-ready check, async,
                        cancel and limit checks). Otherwise it returns 0 and
                        nothing has changed. Tcl_SetCommandInfoFromToken clears
                        the flag if a command's implementation is replaced.
  generic/tclExecute.c  invokeStk / invokeExpanded: look the command up (as
                        EvalObjvCore would), and if it is flagged call
                        TclFastLeafInvoke. If it returns 1 the executor
                        continues as if the NR route had resumed (including
                        restarting the interrupt counter at 1). If not, the
                        looked-up command is handed to TclNREvalObjv, so the
                        lookup is not repeated.

How to try it
  1. Unpack a Tcl source tree at the base commit (see get-base.sh in the lrange
     zip), cd to its root, then:   patch -p1 < /path/to/fastleaf.patch
     or copy new/generic/* over generic/ if your tree matches orig/.
  2. Build as usual (unix: cd unix; ./configure; make).
  3. Behaviour checks. Run each script with a stock tclsh and with the new one
     and compare the outputs (each takes a few seconds):
        stock/tclsh  extras/ff_tests.tcl > a.txt     (guards, one function)
        new/tclsh    extras/ff_tests.tcl > b.txt
        diff -s a.txt b.txt        (expect: Files a.txt and b.txt are identical)
     Same for  extras/ff_scen.tcl  (traces, redefine, limits, cancel,
     recursion, for 30 functions) and  extras/ff_all.tcl  (every function x
     47,734 argument lists, called directly and inside expr; large output).
  4. Timing:  tclsh extras/wall3.tcl   (ns per iteration for 13 functions; also
     wall2.tcl for abs/int/double/floor/proc). Run several times, alternating
     the two builds, and compare medians.

Tests (new in this version)
  tests/fastleaf.test  96 tests. Needs the test build (tcltest), because it uses
  the test commands in tclTest.c. Run from the unix directory:
        make tcltest
        ./tcltest ../tests/fastleaf.test
  or the whole suite:  make test      (fastleaf.test is picked up by all.tcl).
  If you built out of tree or on Windows, run tcltest.exe with the same file;
  on Windows I have not tried it.

  Design (your idea): the same tests run twice in one process. Pass 1 runs
  with the direct path turned off (testfastleaf disable 1) and pass 2 with it
  on; every outcome (return code, result, error code, error info, error line,
  error stack, side effects) is saved in pass 1 and each test checks that pass 2
  is identical. So the reference is the stock route inside the same binary.
    testfastleaf disable ?bool? ?child?   sets/clears FAST_LEAF_OFF on this
                                          interp or a named child; returns
                                          the state after the change.
    testfastleafprobe                     a flagged command that returns how many
                                          NR callbacks are queued while it runs.
                                          fastleaf-route-* use it to prove the
                                          direct route really is taken (4 vs 6),
                                          so the comparison is not vacuous.
  Groups: a sweep of every math function with many argument lists (direct and
  inside expr); per-function scenarios (traces, redefine, rename, delete,
  alias, coroutine, tailcall, limits, expired time limit, cancel, recursion
  limit); namespaces, safe interps and hidden commands; and "extras": cancel,
  command limits, async handlers, C-level command trace, frame debugging, with
  srand/rand used to expose whether a call wrongly ran or was wrongly skipped.

  Mutation check: extras/mutate.py + runmut.sh break the build one guard at a
  time (18 mutations), rebuild tcltest and run fastleaf.test. The paths inside
  the scripts need adjusting. Result: 8 of 18 are caught (interrupt counter
  reset, exec traces, interp-level trace, numLevels, cmdCount, TclInterpReady,
  limit check after the call, FAST_LEAF_OFF). 10 are NOT caught: CMD_DEAD, limit
  already exceeded, cancel flags, debug frame, ensemble-rewrite reset, async
  check after the call, cancel check after the call, nreProc2, deferredCallbacks,
  rewind. My reading is that for the 58 math functions these are unreachable
  from Tcl or are covered by the checks done at resume time, but I have not
  proved it. Treat
  those guards as defensive code that the tests do not distinguish.

Notes
  * Only built and tested on Linux x86-64 (gcc -O2). Not tried on Windows.
  * With USE_DTRACE defined the fast path is compiled out.
