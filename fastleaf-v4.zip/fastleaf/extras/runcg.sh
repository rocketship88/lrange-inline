#!/bin/sh
# usage: runcg.sh TREE(base|fast) CASE N X
D=/tmp/claude-0/-home-claude/c65d3956-49cc-5b06-b086-4ca354d4bd07/scratchpad
if [ "$1" = base ]; then U=/home/claude/tcltk-trunk/tcl/unix; else U=/home/claude/tcltk-trunk/tcl-fast/unix; fi
export LD_LIBRARY_PATH=$U TCL_LIBRARY=$U/../library
valgrind --tool=callgrind --callgrind-out-file=$D/cg5/$1.$2.$3.cg $U/tclsh $D/prof5.tcl $2 $3 $4 2> $D/cg5/$1.$2.$3.err >/dev/null
grep -h "Collected" $D/cg5/$1.$2.$3.err | awk '{print $4}'
