lassign $argv f N
array set A {sin 0.5 pow {2.0 10} atan2 {1.5 2.5} isnan 1.5 isqrt 99 sqrt 16.0 max {3 9 4} min {3 9} fma {2.0 3.0 4.0} lgamma 5.0 round 2.5 ceil 1.5 floor 1.5 isunordered {1.0 2.0} bool 1 wide 5 empty {} rand {} ldexp {1.5 3} hypot {3.0 4.0} exp 1.5 log 2.5}
if {$f eq "empty"} {set body {}} else {set body "expr {$f\([join $A($f) ,])}"}
proc p {N} "for {set k 0} {\$k < \$N} {incr k} {$body}"
p $N
exit
