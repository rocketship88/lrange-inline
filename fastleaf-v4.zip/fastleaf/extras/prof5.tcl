lassign $argv case N X
array set body {
    empty     {}
    abs       {expr {abs($x)}}
    int       {expr {int($x)}}
    double    {expr {double($x)}}
    floor     {expr {floor($x)}}
    lsearch   {lsearch {a b c} a}
    proc      {id $x}
    abs-direct {tcl::mathfunc::abs $x}
    floor-direct {tcl::mathfunc::floor $x}
}
proc id {a} {return $a}
proc p {x N} "for {set k 0} {\$k < \$N} {incr k} {$body($case)}"
p $X $N
exit
