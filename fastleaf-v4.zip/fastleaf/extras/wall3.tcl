array set A {sin 0.5 pow {2.0 10} atan2 {1.5 2.5} isnan 1.5 isqrt 99 sqrt 16.0 max {3 9 4} fma {2.0 3.0 4.0} lgamma 5.0 round 2.5 floor 1.5 exp 1.5 empty {}}
foreach f {empty sin pow atan2 exp isnan sqrt isqrt max fma lgamma round floor} {
    if {$f eq "empty"} {set body {}} else {set body "expr {$f\([join $A($f) ,])}"}
    proc w_$f {n} "for {set k 0} {\$k < \$n} {incr k} {$body}"
    set best 1e9
    for {set r 0} {$r < 3} {incr r} {
        set us [lindex [time {w_$f 500000}] 0]
        if {$us < $best} {set best $us}
    }
    puts "$f [expr {$best*1000.0/500000}]"
}
