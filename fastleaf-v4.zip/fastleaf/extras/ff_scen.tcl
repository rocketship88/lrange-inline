# Scenario differential test: guards and interpreter interactions, per math
# function. Output must be identical between stock and prototype.
set okargs {
    sin {0.5} pow {2 10} atan2 {1 2} ldexp {1.5 3} abs {-3} int {2.7} double {3}
    bool {yes} ceil {1.2} floor {1.7} round {2.5} isqrt {99} sqrt {16} isnan {NaN}
    isunordered {1 NaN} max {3 9 4} min {3 9 4} fma {2 3 4} lgamma {5} wide {5}
    entier {1e20} rand {} srand {7} copysign {3 -1} hypot {3 4} log {2.718281828}
    signbit {-0.0} trunc {2.9} cbrt {27} isfinite {1} issubnormal {1e-320}
}
set badargs {
    sin {zz} pow {2} atan2 {1} ldexp {1 zz} abs {zz} int {zz} double {zz}
    bool {zz} ceil {zz} floor {zz} round {zz} isqrt {-4} sqrt {-1} isnan {zz}
    isunordered {1} max {zz 1} min {1 zz} fma {2 3} lgamma {zz} wide {zz}
    entier {zz} rand {1} srand {zz} copysign {1} hypot {1} log {-1}
    signbit {zz} trunc {zz} cbrt {zz} isfinite {zz} issubnormal {zz}
}
set n 0
proc show {label script} {
    incr ::n
    set c [catch {uplevel 1 $script} m o]
    set out "$::n $label: $c [list $m]"
    if {$c} {foreach k {-errorcode -errorinfo -errorline -errorstack} {
        if {[dict exists $o $k]} {append out " $k=[list [dict get $o $k]]"}}}
    puts $out
}
foreach {f a} $okargs {
    set b [dict get $badargs $f]
    puts "=== $f"
    interp create I
    I eval [list set f $f]
    I eval [list set a $a]
    I eval [list set b $b]
    I eval {
        proc call {args} {tcl::mathfunc::$::f {*}$args}
        set body "tcl::mathfunc::$f $a"
        proc direct {} [list tcl::mathfunc::$f {*}$a]
        proc bad {} [list tcl::mathfunc::$f {*}$b]
        set ex "expr {$f\([join $a ,])}"
        proc viaexpr {} $ex
        if {$f in {rand srand}} {tcl::mathfunc::srand 99}
        proc tr {args} {lappend ::log $args}
        set ::log {}
    }
    proc ishow {label script} {show "$::f $label" [list I eval $script]}
    set f_ $f
    ishow plain   {if {$f in {rand srand}} {tcl::mathfunc::srand 99}; list [direct] [viaexpr]}
    ishow bad     {bad}
    ishow badcatch {catch {bad} m o; list $m [dict get $o -errorcode] [dict get $o -errorline]}
    # execution traces
    ishow trace_on {set ::log {}; trace add execution tcl::mathfunc::$f {enter leave} tr
        if {$f in {rand srand}} {tcl::mathfunc::srand 99}
        set r [list [direct] [viaexpr]]; trace remove execution tcl::mathfunc::$f {enter leave} tr
        list $r $::log}
    ishow trace_off {if {$f in {rand srand}} {tcl::mathfunc::srand 99}; list [direct] $::log}
    ishow trace_err {proc trerr args {error "tracefail"}; trace add execution tcl::mathfunc::$f enter trerr
        set c [catch direct m]; trace remove execution tcl::mathfunc::$f enter trerr; list $c $m}
    # command counting
    ishow cmdcount {set x [info cmdcount]; direct; direct; viaexpr; expr {[info cmdcount] - $x}}
    # rename away / back, redefine, delete
    ishow rename_away {rename tcl::mathfunc::$f ::saved_fn; set c [catch direct m]; rename ::saved_fn tcl::mathfunc::$f; list $c $m [direct]}
    ishow redefine {rename tcl::mathfunc::$f ::saved_fn; proc tcl::mathfunc::$f args {return REDEF}
        set r [list [direct] [viaexpr]]; rename tcl::mathfunc::$f {}; rename ::saved_fn tcl::mathfunc::$f; list $r [direct]}
    ishow delete_then_restore {rename tcl::mathfunc::$f ::saved_fn; rename ::saved_fn {}; set c [catch direct m]
        list $c $m}
    # alias and import
    ishow alias {interp alias {} al_$f {} tcl::mathfunc::$f; proc viaal {} [list al_$f {*}$::a]; if {$f in {rand srand}} {tcl::mathfunc::srand 99}; viaal}
    # error inside catch/try inside loops
    ishow try_loop {set r {}; for {set i 0} {$i < 3} {incr i} {try {bad} on error {m} {lappend r $m}}; set r}
    # coroutine
    ishow coro {coroutine co1 apply {{} {yield [direct]; direct; return done}}; list [co1] [co1]}
    # tailcall and uplevel
    ishow tailcall {proc tc {} {tailcall direct}; tc}
    ishow uplevel {proc up {} {uplevel 1 direct}; up}
    interp delete I

    # limits: the command limit must stop at the same iteration
    foreach lim {7 30} {
        interp create L
        L eval [list set f $f]
        L eval [list set a $a]
        L eval {proc lp {} {set i 0; while 1 {tcl::mathfunc::$::f {*}$::a; incr i; set ::i $i}}}
        L limit command -value [expr {[L eval {info cmdcount}] + $lim}]
        set c [catch {L eval lp} m]
        L limit command -value {}
        puts "$f limit $lim: $c [list $m] i=[L eval {set ::i}]"
        interp delete L
    }
    interp create L
    L eval [list set f $f]; L eval [list set a $a]
    L eval {proc lp {} {set i 0; while 1 {expr {1}; tcl::mathfunc::$::f {*}$::a; incr i; set ::i $i}}}
    L limit command -value [expr {[L eval {info cmdcount}] + 60}] -granularity 5
    set c [catch {L eval lp} m]
    L limit command -value {}
    puts "$f limit gran: $c [list $m] i=[L eval {set ::i}]"
    interp delete L
    interp create L
    L eval [list set f $f]; L eval [list set a $a]
    L eval {proc lp {} {for {set i 0} {$i < 3} {incr i} {tcl::mathfunc::$::f {*}$::a}; return done}}
    L limit time -seconds [expr {[clock seconds] - 10}]
    puts "$f expired time: [catch {L eval lp} m] [list $m]"
    interp delete L
    # cancel
    interp create C
    C eval [list set f $f]; C eval [list set a $a]
    C eval {proc cm {} {set r 0; for {set i 0} {$i < 8} {incr i} {if {$i == 3} {interp cancel}; tcl::mathfunc::$::f {*}$::a; set r $i}; return $r}}
    puts "$f cancel: [catch {C eval cm} m] [list $m]"
    puts "$f after cancel: [catch {C eval {set x 1}} m] [list $m]"
    interp delete C
    # recursion limit
    interp create R
    R eval [list set f $f]; R eval [list set a $a]
    R eval {proc deep {n} {if {$n == 0} {return [tcl::mathfunc::$::f {*}$::a]}; deep [expr {$n-1}]}}
    foreach d {10 37 38 39 40 41 60} {
        R eval {interp recursionlimit {} 40; tcl::mathfunc::srand 5}
        puts "$f deep $d: [catch {R eval [list deep $d]} m] [list $m]"
    }
    interp delete R
}
puts "done"
