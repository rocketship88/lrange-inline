#!/bin/sh
D=/tmp/claude-0/-home-claude/c65d3956-49cc-5b06-b086-4ca354d4bd07/scratchpad
U=/home/claude/tcltk-trunk/tcl-fast/unix
cd $D
: > mut/results.txt
for m in $MUTS; do
  python3 mutate.py $m || { echo "$m MUTATE-FAILED" >> mut/results.txt; continue; }
  (cd $U && make -j2 tcltest > $D/mut/build.log 2>&1) || { echo "$m BUILD-FAILED" >> mut/results.txt; continue; }
  (cd $U && LD_LIBRARY_PATH=$U TCL_LIBRARY=$U/../library timeout 300 ./tcltest ../tests/fastleaf.test > $D/mut/$m.out 2>&1)
  tot=$(grep -E "fastleaf.test:.Total" mut/$m.out | tail -1)
  fails=$(grep -E "^==== .* FAILED" mut/$m.out | sed 's/==== //; s/ FAILED//' | head -6 | tr '\n' ' ')
  echo "$m | $tot | $fails" >> mut/results.txt
done
python3 mutate.py good
(cd $U && make -j2 tcltest > $D/mut/build.log 2>&1)
echo ALLDONE >> mut/results.txt
