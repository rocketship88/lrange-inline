# Behavioural transcript for the fast-leaf prototype. Run with the stock
# tclsh and with the prototype tclsh; the two outputs must be identical.
# Every case prints a label and the observable results (including full
# return options) so any difference shows up in a diff.

set ::n 0
proc show {label script} {
    incr ::n
    set code [catch {uplevel 1 $script} m opts]
    # -errorstack/-errorinfo/-errorline are part of what must not change
    puts "$::n $label: code=$code result=[list $m]"
    if {$code} {
	foreach k {-errorcode -errorinfo -errorline -errorstack -code -level} {
	    if {[dict exists $opts $k]} {puts "    $k = [list [dict get $opts $k]]"}
	}
    }
}

# --- values -----------------------------------------------------------
proc vals {} {
    foreach v {0 -0 1 -1 7 -7 0x10 -0x10 010 0b101 1e3 -1e3 2.5 -2.5 -0.0 0.0
	    9223372036854775807 -9223372036854775808 -9223372036854775809
	    123456789012345678901234567890 -123456789012345678901234567890
	    Inf -Inf NaN inf nan " 5" "5 " "" a 1a} {
	foreach f {abs int double} {
	    set c [catch {tcl::mathfunc::$f $v} m]
	    puts "  $f [list $v] -> $c [list $m]"
	}
	proc cmp1 {x} {list [catch {expr {abs($x)}} a] $a [catch {expr {int($x)}} b] $b [catch {expr {double($x)}} c] $c}
	puts "  expr [list $v] -> [cmp1 $v]"
    }
}
show values vals

# --- argument count errors, error details ------------------------------
show noargs  {tcl::mathfunc::abs}
show twoargs {tcl::mathfunc::int 1 2}
show badnum  {tcl::mathfunc::double zzz}
proc errline {x} {
    set a 1
    set b [expr {
	abs($a)
	+ int($x)
    }]
    return $b
}
show errline {errline abc}
show errline_ok {errline 4.9}
proc nested {x} {
    foreach i {1 2 3} {
	catch {abs_wrapper $x} m
	lappend r $m
    }
    return $r
}
proc abs_wrapper {x} {tcl::mathfunc::abs $x}
show nested {nested q}
proc withtry {x} {
    try {tcl::mathfunc::abs $x} on error {m o} {return "caught: $m [dict get $o -errorcode]"}
}
show try {withtry foo}
show try_ok {withtry -4}

# --- redefinition, rename, delete (in a scratch interp) -------------------
interp create D
D eval {
    proc useabs {x} {tcl::mathfunc::abs $x}
    proc useabs_expr {x} {expr {abs($x)}}
}
proc dshow {label script} {show $label [list D eval $script]}
dshow before_redef  {list [useabs -3] [useabs_expr -3]}
D eval {rename tcl::mathfunc::abs ::saved_abs}
dshow renamed_away  {useabs -3}
dshow renamed_away2 {useabs_expr -3}
D eval {rename ::saved_abs tcl::mathfunc::abs}
dshow renamed_back  {list [useabs -3] [useabs_expr -3]}
D eval {proc tcl::mathfunc::abs {x} {return "REDEF($x)"}}
dshow redefined     {list [useabs -3] [useabs_expr -3]}
D eval {rename tcl::mathfunc::abs ""}
dshow deleted       {useabs -3}
dshow deleted2      {useabs_expr -3}
D eval {proc tcl::mathfunc::abs {x} {return "REDEF2($x)"}}
dshow redefined2    {list [useabs -3] [useabs_expr -3]}
D eval {rename tcl::mathfunc::abs ""}
set tmpi [interp create]
interp alias D tcl::mathfunc::abs $tmpi tcl::mathfunc::abs
dshow alias_to_other_interp {list [useabs -3] [useabs_expr -3]}
D eval {rename tcl::mathfunc::abs ""}
interp delete $tmpi
interp delete D
interp create J
J eval {proc useabs {x} {tcl::mathfunc::abs $x}}

# --- execution traces ---------------------------------------------------
J eval {
    set ::log {}
    proc tr {args} {lappend ::log $args}
    proc useint {x} {expr {int($x)}}
    proc useint2 {x} {tcl::mathfunc::int $x}
}
puts "traces:"
puts [J eval {useint2 4.7}]
J eval {trace add execution tcl::mathfunc::int {enter leave} tr}
puts [J eval {list [useint2 4.7] [useint 5.5]}]
puts [J eval {set ::log}]
J eval {set ::log {}; trace remove execution tcl::mathfunc::int {enter leave} tr}
puts [J eval {list [useint2 4.7] [useint 5.5] $::log}]
# trace added from inside a loop, between calls of the same compiled proc
J eval {
    set ::log {}
    proc loop {} {
	for {set i 0} {$i < 6} {incr i} {
	    if {$i == 2} {trace add execution tcl::mathfunc::double enter tr}
	    if {$i == 4} {trace remove execution tcl::mathfunc::double enter tr}
	    tcl::mathfunc::double $i
	}
    }
    loop
}
puts [J eval {set ::log}]
# trace that errors, and trace that deletes the traced command
J eval {
    proc trerr {args} {error "trace failed"}
    trace add execution tcl::mathfunc::double enter trerr
}
show trace_error {J eval {tcl::mathfunc::double 3}}
J eval {trace remove execution tcl::mathfunc::double enter trerr}
show after_trace {J eval {tcl::mathfunc::double 3}}
# rename / delete traces on the flagged command
J eval {set ::log {}; trace add command tcl::mathfunc::abs {rename delete} tr}
J eval {rename tcl::mathfunc::abs ::tmp_abs; rename ::tmp_abs tcl::mathfunc::abs}
puts [J eval {set ::log}]
puts [J eval {useabs -9}]

# --- command count ------------------------------------------------------
J eval {
    proc cnt {} {
	set a [info cmdcount]
	tcl::mathfunc::abs -1
	tcl::mathfunc::abs -1
	tcl::mathfunc::int 2.5
	set b [info cmdcount]
	expr {$b - $a}
    }
}
puts "cmdcount delta: [J eval cnt]"
J eval {
    proc cnt2 {} {
	set a [info cmdcount]
	expr {abs(-1) + int(2.5) + double(3)}
	set b [info cmdcount]
	expr {$b - $a}
    }
}
puts "cmdcount delta (expr): [J eval cnt2]"

# --- command limit: stops at the same iteration --------------------------
foreach lim {5 17 40} {
    interp create L
    L eval {proc lp {} {set i 0; while 1 {tcl::mathfunc::abs -1; incr i; set ::i $i}}}
    L limit command -value [expr {[L eval {info cmdcount}] + $lim}]
    set c [catch {L eval lp} m]
    L limit command -value {}
    puts "limit $lim: code=$c m=[list $m] i=[L eval {set ::i}]"
    interp delete L
}
# limit with granularity
interp create L
L eval {proc lp {} {set i 0; while 1 {expr {int(1.5)}; incr i; set ::i $i}}}
L limit command -value [expr {[L eval {info cmdcount}] + 50}] -granularity 7
set c [catch {L eval lp} m]
L limit command -value {}
puts "limit gran: code=$c m=[list $m] i=[L eval {set ::i}]"
interp delete L
# time limit that is already expired
interp create L
L eval {proc lp {} {for {set i 0} {$i < 3} {incr i} {tcl::mathfunc::abs -1}; return done}}
L limit time -seconds [expr {[clock seconds] - 10}]
puts "expired time limit: [catch {L eval lp} m] [list $m]"
interp delete L

# --- cancel ---------------------------------------------------------------
interp create C
C eval {
    proc cancelme {} {
	set r {}
	for {set i 0} {$i < 8} {incr i} {
	    if {$i == 3} {interp cancel}
	    lappend r [tcl::mathfunc::abs -$i]
	}
	return $r
    }
}
puts "cancel: [catch {C eval cancelme} m] [list $m]"
puts "after cancel: [catch {C eval {tcl::mathfunc::abs -1}} m] [list $m]"
interp delete C

# --- recursion limit / nesting ---------------------------------------------
interp create R
R eval {
    proc rec {n} {tcl::mathfunc::abs [rec2 [expr {$n+1}]]}
    proc rec2 {n} {rec $n}
}
R eval {interp recursionlimit {} 40}
set c [catch {R eval {rec 0}} m]
puts "recursion: code=$c m=[list $m]"
R eval {
    proc deep {n} {
	if {$n == 0} {return [tcl::mathfunc::abs -1]}
	deep [expr {$n-1}]
    }
}
foreach d {10 20 35 38 39 40 41 45} {
    R eval {interp recursionlimit {} 40}
    set c [catch {R eval [list deep $d]} m]
    puts "deep $d: code=$c m=[list $m]"
}
interp delete R

# --- namespaces: relative names, shadowing, import ---------------------------
namespace eval ::q {
    proc t1 {} {abs -5}
    proc t2 {} {tcl::mathfunc::abs -5}
}
show ns_unqualified_missing {::q::t1}
namespace eval ::tcl::mathfunc {
    proc t3 {} {abs -5}
    proc t4 {} {int 5.9}
}
show ns_inside_mathfunc  {list [::tcl::mathfunc::t3] [::tcl::mathfunc::t4]}
namespace eval ::q {proc abs {x} {return "q::abs($x)"}}
show ns_shadow {list [::q::t1] [::q::t2]}
namespace eval ::z {namespace import ::tcl::mathfunc::int; proc t {} {int 8.8}}
show ns_import {::z::t}
interp alias {} myint {} tcl::mathfunc::int
show alias {myint 3.9}
proc viaalias {} {myint 3.9}
show alias_bc {viaalias}
rename tcl::mathfunc::int ::hid_int
show alias_after_rename {viaalias}
rename ::hid_int tcl::mathfunc::int
show alias_back {viaalias}

# --- ensemble / unknown ---------------------------------------------------
rename unknown ::unknown_saved
proc unknown {args} {return "UNKNOWN: $args"}
interp create U
show unknown_hook {tcl::mathfunc::nosuch 1}
rename tcl::mathfunc::double ::dbl_saved
show unknown_for_double {tcl::mathfunc::double 1}
rename ::dbl_saved tcl::mathfunc::double
rename unknown {}
rename ::unknown_saved unknown
interp delete U

# --- safe interp -----------------------------------------------------------
interp create -safe S
show safe_expr {S eval {expr {abs(-3) + int(2.5) + double(1)}}}
show safe_direct {S eval {tcl::mathfunc::abs -3}}
S eval {proc w {x} {tcl::mathfunc::abs $x}}
S eval {rename tcl::mathfunc::abs ::gabs}
show safe_moved {S eval {w -3}}
S hide gabs
show safe_hidden {S eval {w -3}}
show safe_hidden_invoke {S invokehidden gabs -3}
S expose gabs
S eval {rename ::gabs tcl::mathfunc::abs}
show safe_exposed {S eval {w -3}}
interp delete S

# --- coroutines ------------------------------------------------------------
proc gen {} {
    yield [tcl::mathfunc::abs -1]
    yield [tcl::mathfunc::int 2.5]
    yield [expr {double(3)}]
    return [tcl::mathfunc::abs -4]
}
coroutine g1 gen
show coro {list [g1] [g1] [g1] [catch {g1} m] $m}

# --- uplevel/global-eval and non-bytecode callers -----------------------------
show eval_global   {eval {tcl::mathfunc::abs -2}}
show uplevel_calls {uplevel #0 {tcl::mathfunc::int 7.7}}
show string_eval   {eval "tcl::mathfunc::double 5"}
show apply         {apply {{x} {tcl::mathfunc::abs $x}} -6}
show expanded      {set a {-8}; tcl::mathfunc::abs {*}$a}
show expanded_none {set a {}; tcl::mathfunc::abs {*}$a 4}
show expanded_two  {set a {1 2}; tcl::mathfunc::abs {*}$a}
show dyn_name      {set f abs; tcl::mathfunc::$f -3}
show assemble      {tcl::unsupported::assemble {push tcl::mathfunc::abs; push -3; invokeStk 2}}
show assemble_bad  {tcl::unsupported::assemble {push tcl::mathfunc::abs; push zz; invokeStk 2}}

# --- result handling: shared result object, result reset ---------------------
proc keep {} {
    set a [tcl::mathfunc::abs -5]
    set b [tcl::mathfunc::abs -6]
    set c [tcl::mathfunc::int $a]
    list $a $b $c [string length $a] [expr {$a + $b}]
}
show results {keep}
proc errcode {} {
    catch {tcl::mathfunc::abs q} m o
    set ::errorCode_seen [dict get $o -errorcode]
    catch {tcl::mathfunc::abs 5} m2 o2
    list $::errorCode_seen $m2 [dict exists $o2 -errorcode] $::errorCode
}
show errcode {errcode}
show errorInfo_global {catch {tcl::mathfunc::abs q}; set ::errorInfo}
show interp_result_cleared {set x [tcl::mathfunc::abs -2]; interp result {} ; set y [tcl::mathfunc::abs -3]; list $x $y}

# --- ensemble rewrite state (error text from ensembles must be unaffected) -----
show ensemble_err {string length}
show ensemble_err2 {dict get}
show ensemble_after_abs {catch {string foo} m; tcl::mathfunc::abs -1; catch {string foo} m2; list $m $m2}

puts "total cases: $::n"
