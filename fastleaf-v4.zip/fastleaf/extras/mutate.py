import sys,re
G='/home/claude/tcltk-trunk/tcl-fast/generic/'
D='/tmp/claude-0/-home-claude/c65d3956-49cc-5b06-b086-4ca354d4bd07/scratchpad/mut/'
name=sys.argv[1]
b=open(D+'tclBasic.c.good').read()
e=open(D+'tclExecute.c.good').read()
i=b.index("\nTclFastLeafInvoke(\n"); j=b.index("\n}\n",i)
fn=b[i:j]
def sub(s,old,new):
    assert s.count(old)==1,(name,old,s.count(old))
    return s.replace(old,new)
M={}
M['M01_no_interrupt_reset']=('e',("interruptCounter = 1;\n\t\t\tgoto resumeFromInvocation;","goto resumeFromInvocation;"))
M['M02_ignore_exec_traces']=('b',("(cmdPtr->flags & (CMD_HAS_EXEC_TRACES | CMD_DEAD))","(cmdPtr->flags & (CMD_DEAD))"))
M['M03_ignore_dead']=('b',("(cmdPtr->flags & (CMD_HAS_EXEC_TRACES | CMD_DEAD))","(cmdPtr->flags & (CMD_HAS_EXEC_TRACES))"))
M['M04_ignore_interp_trace']=('b',("\t    || iPtr->deferredCallbacks\n\t    || iPtr->tracePtr\n","\t    || iPtr->deferredCallbacks\n"))
M['M05_ignore_limit_exceeded']=('b',("\t    || TclLimitExceeded(iPtr->limit)\n","\n"))
M['M06_ignore_cancel_flags']=('b',("(CANCELED | TCL_CANCEL_UNWIND\n\t\t| INTERP_DEBUG_FRAME | FAST_LEAF_OFF)","(INTERP_DEBUG_FRAME | FAST_LEAF_OFF)"))
M['M07_ignore_debug_frame']=('b',("\t\t| INTERP_DEBUG_FRAME | FAST_LEAF_OFF))","\t\t| FAST_LEAF_OFF))"))
M['M08_ignore_off_flag']=('b',("\t\t| INTERP_DEBUG_FRAME | FAST_LEAF_OFF))","\t\t| INTERP_DEBUG_FRAME))"))
M['M09_no_numlevels']=('b',("iPtr->numLevels++;\t\t\t\t/* TclNREvalObjv */","\n"),("iPtr->numLevels--;\t\t\t\t/* NRCommand */","\n"))
M['M10_no_cmdcount']=('b',("iPtr->cmdCount++;\t\t\t/* Dispatch */","\n"))
M['M11_no_rewrite_reset']=('b',("TclResetRewriteEnsemble(interp, 1);\t\t/* EvalObjvCore */","\n"))
M['M12_no_interp_ready']=('b',("if (TCL_OK != TclInterpReady(interp)) {","if (0) {"))
M['M13_no_async']=('b',("    if (TclAsyncReady(iPtr)) {\n\tresult = Tcl_AsyncInvoke(interp, result);\n    }\n","\n"))
M['M14_no_cancel_after']=('b',("    if ((result == TCL_OK) && TclCanceled(iPtr)) {\n\tresult = Tcl_Canceled(interp, TCL_LEAVE_ERR_MSG);\n    }\n","\n"))
M['M15_no_limit_after']=('b',("    if (result == TCL_OK && TclLimitReady(iPtr->limit)) {\n\tresult = Tcl_LimitCheck(interp);\n    }\n","\n"))
M['M16_ignore_nre_proc']=('b',("\t    || cmdPtr->nreProc2 != NULL\n","\n"))
M['M17_ignore_deferred']=('b',("\t    || iPtr->deferredCallbacks\n","\n"))
M['M18_ignore_rewind']=('b',("\t    || iPtr->execEnvPtr->rewind) {","\t    ) {"))
if name=='good':
    open(G+'tclBasic.c','w').write(b); open(G+'tclExecute.c','w').write(e); sys.exit()
spec=M[name]; which=spec[0]
if which=='b':
    f=fn
    for old,new in spec[1:]: f=sub(f,old,new)
    b=b[:i]+f+b[j:]
else:
    for old,new in spec[1:]: e=sub(e,old,new)
open(G+'tclBasic.c','w').write(b); open(G+'tclExecute.c','w').write(e)
