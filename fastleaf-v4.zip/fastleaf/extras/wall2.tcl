proc id {a} {return $a}
proc w_empty {x n} {for {set k 0} {$k < $n} {incr k} {}}
proc w_abs {x n} {for {set k 0} {$k < $n} {incr k} {expr {abs($x)}}}
proc w_int {x n} {for {set k 0} {$k < $n} {incr k} {expr {int($x)}}}
proc w_double {x n} {for {set k 0} {$k < $n} {incr k} {expr {double($x)}}}
proc w_three {x n} {for {set k 0} {$k < $n} {incr k} {expr {abs($x) + int($x) + double($x)}}}
proc w_sumabs {x n} {set s 0; for {set k 0} {$k < $n} {incr k} {set s [expr {$s + abs($k - 500)}]}; set s}
proc w_floor {x n} {for {set k 0} {$k < $n} {incr k} {expr {floor($x)}}}
proc w_lsearch {x n} {for {set k 0} {$k < $n} {incr k} {lsearch {a b c} a}}
proc w_proc {x n} {for {set k 0} {$k < $n} {incr k} {id $x}}
foreach c {empty abs int double three sumabs floor lsearch proc} {
    set best 1e9
    for {set r 0} {$r < 3} {incr r} {
        set us [lindex [time {w_$c -7.5 500000}] 0]
        if {$us < $best} {set best $us}
    }
    puts "$c [expr {$best*1000.0/500000}]"
}
