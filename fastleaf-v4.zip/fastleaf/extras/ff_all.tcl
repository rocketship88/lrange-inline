# Differential test over every ::tcl::mathfunc function.
# Run with the stock tclsh and the prototype tclsh; outputs must be identical.
# For each function and each argument list, the function is called two ways
# (directly by name -> invokeStk, and inside expr) and the complete outcome is
# printed: return code, result, and for errors the error code, error info,
# error line and error stack.

set v1 {0 -0 1 -1 2 3 7 -7 0.5 -0.5 2.5 -2.5 1e300 -1e300 1e-300 4.9e-324
    9223372036854775807 -9223372036854775808 9223372036854775808
    -9223372036854775809 18446744073709551616
    123456789012345678901234567890 -123456789012345678901234567890
    Inf -Inf NaN inf nan 0x10 -0x10 010 0b11 " 5" "5 " "" a 1a 1.0 -0.0
    3.14159 100 1e10 65 {1 2} 1e400 true false yes 1e15 1e16 -1e16 0.1 255 256}
set v2 {0 1 -1 2 7 2.5 -2.5 1e300 9223372036854775807 123456789012345678901234567890 Inf NaN a 0.5 3 64}
set v3 {0 1 -1 2.5 NaN 1e300 a 7}

proc outcome {script} {
    set code [catch {uplevel 1 $script} m opts]
    set out "$code [list $m]"
    if {$code} {
	foreach k {-errorcode -errorinfo -errorline -errorstack} {
	    if {[dict exists $opts $k]} {append out " $k=[list [dict get $opts $k]]"}
	}
    }
    return $out
}

# deterministic generator state for rand/srand
set funcs [lsort [lmap c [info commands ::tcl::mathfunc::*] {namespace tail $c}]]
puts "functions: [llength $funcs]"
set total 0
foreach f $funcs {
    set nondet [expr {$f eq "rand"}]
    set argsets {{}}
    foreach a $v1 {lappend argsets [list $a]}
    foreach a $v2 {foreach b $v2 {lappend argsets [list $a $b]}}
    foreach a $v3 {foreach b $v3 {foreach c $v3 {lappend argsets [list $a $b $c]}}}
    foreach args $argsets {
	incr total
	if {$f eq "srand" || $f eq "rand"} {
	    # seed first so the result is reproducible; seeding itself is covered below
	    tcl::mathfunc::srand 12345
	}
	set n [llength $args]
	# direct call: literal command name, literal args -> invokeStk
	set argv {}
	set i 0
	foreach a $args {append argv " \$a$i"; incr i}
	set pl {}
	for {set i 0} {$i < $n} {incr i} {lappend pl a$i}
	catch {rename tdirect ""}
	proc tdirect $pl "tcl::mathfunc::$f$argv"
	catch {rename texpr ""}
	set cargs [join [lmap p $pl {string cat \$ $p}] ,]
	set perr [catch {proc texpr $pl "expr {$f\($cargs)}"} pm]
	if {$f eq "srand" || $f eq "rand"} {tcl::mathfunc::srand 12345}
	set r1 [outcome {tdirect {*}$args}]
	if {$f eq "srand" || $f eq "rand"} {tcl::mathfunc::srand 12345}
	set r2 [expr {$perr ? "proc: $pm" : [outcome {texpr {*}$args}]}]
	puts "$f [list $args] | $r1 | $r2"
    }
}
# rand/srand sequences
foreach seed {0 1 42 -5 2147483647 2147483648 1e3 a} {
    puts "srand [list $seed]: [outcome {tcl::mathfunc::srand $seed}] [outcome {list [tcl::mathfunc::rand] [tcl::mathfunc::rand] [expr {rand()}]}]"
}
puts "total argument lists: $total"
